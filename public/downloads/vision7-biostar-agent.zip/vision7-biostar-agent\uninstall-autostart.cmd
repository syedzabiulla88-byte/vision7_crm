@echo off
schtasks /Delete /TN "Vision7BioStarAgent" /F
echo  Removed. (The agent will no longer auto-start.)
pause
