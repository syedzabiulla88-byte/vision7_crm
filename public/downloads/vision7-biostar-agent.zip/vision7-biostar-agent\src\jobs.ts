import type { Actions } from "./actions.js";
import type { BackendClient } from "./backend.js";
import type { BiostarClient } from "./biostar.js";
import type { Env } from "./env.js";
import type { Job, JobResult, Subject } from "./types.js";
import { syncInventory, syncEvents } from "./sync.js";
import { log } from "./log.js";

/** Coerce a job payload into a Subject. */
function readSubject(payload: Record<string, unknown> | null | undefined): Subject {
  const p = payload ?? {};
  const kind = String(p.subjectKind ?? "");
  if (!kind) throw new Error("job payload missing subjectKind");
  return {
    subjectKind: kind as Subject["subjectKind"],
    subjectId: String(p.subjectId ?? ""),
    name: typeof p.name === "string" ? p.name : undefined,
    biostarUserId: typeof p.biostarUserId === "string" ? p.biostarUserId : undefined,
  };
}

function str(p: Record<string, unknown> | null | undefined, key: string): string | undefined {
  const v = (p ?? {})[key];
  return typeof v === "string" ? v : v == null ? undefined : String(v);
}

function strArr(p: Record<string, unknown> | null | undefined, key: string): string[] {
  const v = (p ?? {})[key];
  if (Array.isArray(v)) return v.map((x) => String(x));
  return [];
}

/**
 * Execute a single claimed job and post the result back. A SYNC_INVENTORY or
 * SYNC_EVENTS job piggybacks on the same sync routines used by the loop.
 */
export async function runJob(
  job: Job,
  ctx: {
    actions: Actions;
    biostar: BiostarClient;
    backend: BackendClient;
    env: Env;
    /** Mutable watermark holder for SYNC_EVENTS jobs. */
    watermark: { value: string };
  },
): Promise<void> {
  const p = job.payload ?? {};
  let result: JobResult;

  try {
    let data: Record<string, unknown>;
    switch (job.type) {
      case "SCAN_CARD":
        data = await ctx.actions.scanCard(str(p, "readerId"));
        break;
      case "ENSURE_USER":
        data = await ctx.actions.ensureUser(readSubject(p));
        break;
      case "ENROLL_CARD":
        data = await ctx.actions.enrollCard({
          cardId: str(p, "cardId") ?? "",
          cardType: str(p, "cardType"),
          wiegandFormatId: str(p, "wiegandFormatId"),
        });
        break;
      case "ASSIGN_CARD":
        data = await ctx.actions.assignCard({
          biostarUserId: str(p, "biostarUserId") ?? "",
          biostarCardId: str(p, "biostarCardId") ?? "",
        });
        break;
      case "ISSUE_CARD":
        data = await ctx.actions.issueCard({
          subject: readSubject(p),
          cardId: str(p, "cardId") ?? "",
          cardType: str(p, "cardType"),
          wiegandFormatId: str(p, "wiegandFormatId"),
          doorIds: strArr(p, "doorIds"),
        });
        break;
      case "REVOKE_CARD":
        data = await ctx.actions.revokeCard({
          biostarUserId: str(p, "biostarUserId") ?? "",
          biostarCardId: str(p, "biostarCardId"),
        });
        break;
      case "GRANT_ACCESS":
        data = await ctx.actions.grantAccess({
          biostarUserId: str(p, "biostarUserId") ?? "",
          doorIds: strArr(p, "doorIds"),
        });
        break;
      case "REVOKE_ACCESS":
        data = await ctx.actions.revokeAccess({
          biostarUserId: str(p, "biostarUserId") ?? "",
        });
        break;
      case "RENAME_DEVICE":
        data = await ctx.actions.renameDevice({
          deviceId: str(p, "deviceId") ?? "",
          name: str(p, "name") ?? "",
        });
        break;
      case "SYNC_INVENTORY":
        await syncInventory(ctx.biostar, ctx.backend);
        data = { synced: "inventory" };
        break;
      case "SYNC_EVENTS":
        ctx.watermark.value = await syncEvents(
          ctx.biostar,
          ctx.backend,
          ctx.env,
          str(p, "since") ?? ctx.watermark.value,
        );
        data = { synced: "events", watermark: ctx.watermark.value };
        break;
      default:
        throw new Error(`unknown job type ${String(job.type)}`);
    }
    result = { status: "DONE", result: data };
    log.info(`job ${job.id} ${job.type} DONE`, data);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    result = { status: "FAILED", error: message };
    log.error(`job ${job.id} ${job.type} FAILED`, message);
  }

  await ctx.backend.safe(`postJobResult(${job.id})`, () => ctx.backend.postJobResult(job.id, result));
}
