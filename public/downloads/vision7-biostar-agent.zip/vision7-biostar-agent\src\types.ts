/**
 * Shared types for the Vision7 BioStar on-prem agent.
 * These mirror the SHARED CONTRACT (backend <-> agent), nothing more.
 */

/** Connection config the agent fetches from the backend. */
export interface AgentConfig {
  enabled: boolean;
  host: string;
  port: string;
  /** BioStar application/service-account login id. */
  login_id: string;
  /** Decrypted BioStar password (only ever held in-memory). */
  password: string;
  /** When true (default), the agent performs NO mutating BioStar calls. */
  dry_run: boolean;
  /** Optional default reader/device id used for card enrollment scans. */
  enrollment_reader_id?: string | null;
}

/** Job types the backend queue can hand to the agent. */
export type JobType =
  | "SCAN_CARD"
  | "ENSURE_USER"
  | "ENROLL_CARD"
  | "ASSIGN_CARD"
  | "ISSUE_CARD"
  | "REVOKE_CARD"
  | "GRANT_ACCESS"
  | "REVOKE_ACCESS"
  | "SYNC_INVENTORY"
  | "SYNC_EVENTS";

/** A single queued job claimed from the backend. */
export interface Job {
  id: string;
  type: JobType;
  payload?: Record<string, unknown> | null;
}

/** Result the agent posts back for a job. */
export interface JobResult {
  status: "DONE" | "FAILED";
  result?: Record<string, unknown> | null;
  error?: string | null;
}

/** Subject reference (who a card / access belongs to). */
export interface Subject {
  subjectKind: "ATHLETE" | "CRM_CONTACT" | "USER" | "FAMILY_MEMBER";
  subjectId: string;
  /** Optional human fields used when we must create a BioStar user. */
  name?: string;
  /** Existing BioStar user id, if already linked. */
  biostarUserId?: string;
}

/* ---- BioStar wire shapes (only the fields we touch) ---- */

export interface BiostarDevice {
  id: string;
  name?: string;
  device_type?: string;
  /** "1" = online per contract. */
  status?: string;
  ip?: string;
}

export interface BiostarDoor {
  id: string;
  name?: string;
  /** Door is bound to a device; shape varies by firmware. */
  device_id?: string;
}

export interface ScanResult {
  card_type?: string;
  card_id?: string;
  wiegand_format_id?: string;
}

export interface BiostarEvent {
  id?: string;
  /** event id alternative key on some firmwares */
  index?: string | number;
  user_id?: { user_id?: string } | string;
  door_id?: { id?: string } | string;
  door_name?: string;
  /** event_type_id determines GRANTED vs DENIED on some firmwares. */
  event_type_id?: { code?: string; id?: string } | string;
  datetime?: string;
  [k: string]: unknown;
}

/** Normalised event we push to the backend. */
export interface NormalisedEvent {
  biostarEventId?: string;
  biostarUserId?: string;
  doorId?: string;
  doorName?: string;
  result?: "GRANTED" | "DENIED";
  at: string;
  raw: unknown;
}

/** Normalised inventory payload pushed to the backend. */
export interface InventoryPayload {
  devices: Array<{
    id: string;
    name?: string;
    deviceType?: string;
    status?: string;
    ip?: string;
  }>;
  doors: Array<{ id: string; name?: string; deviceId?: string }>;
}
