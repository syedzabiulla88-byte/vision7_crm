# Vision7 BioStar Agent (on-prem bridge)

The **only** process that talks to the BioStar 2 controller. It runs on a machine
on the **premises LAN** (same network as the BioStar appliance) and is fully
decoupled from the cloud:

```
  CRM (browser)  ──►  Cloud backend (NestJS, the BRAIN)  ◄── outbound HTTPS ──  THIS AGENT  ──►  BioStar 2 API (LAN, self-signed TLS)
                       stores config + job queue + caches                       executes jobs, syncs inventory + events
```

- The **backend never calls BioStar.** It only stores connection config + mappings,
  holds a **job queue**, and caches inventory/events.
- This **agent** makes only **outbound** HTTPS calls to the backend
  (it does not need an inbound port open), then talks to BioStar locally.
- The agent **pulls** its BioStar credentials from the backend at runtime
  (`GET /access-control/agent/config`) — credentials are never stored on this box.

## Quick start (Windows — the easy way)

Install **Node 18+** once on this machine (https://nodejs.org → LTS), then:

1. Copy this whole `biostar-agent` folder onto the premises PC/server.
2. In a terminal in this folder, run once: **`npm install`** then **`npm run build`**.
3. Copy **`config.env.example`** → **`config.env`** and edit two lines:
   - `BACKEND_URL=https://api.vision7.sa/api`
   - `AGENT_KEY=` paste the key from **CRM → Settings → BioStar**
4. Double-click **`start.cmd`** to run it (close the window to stop).
5. To run it automatically at login: double-click **`install-autostart.cmd`**.

The BioStar host / login / password / dry-run all live in **CRM → Settings → BioStar** — never on this box. Keep **dry-run ON** until the first live test together.

### Always-on server (start at boot, no login)

Run once **as Administrator** (fix the path):
```
schtasks /Create /TN "Vision7BioStarAgent" /SC ONSTART /RU SYSTEM /F /TR "\"C:\path\to\biostar-agent\start-headless.cmd\""
```
…or use NSSM / pm2 pointing at `node dist\index.js`.

## What it does each cycle (~every 15s)

1. `GET /access-control/agent/config` — reload connection config + `dry_run`.
2. **Sync inventory**: read BioStar `GET /devices` + `GET /doors`, push to
   `POST /access-control/agent/sync/inventory` (this also acts as the **heartbeat**).
3. **Sync events**: `POST /api/events/search` from a moving watermark, normalise,
   push to `POST /access-control/agent/sync/events` (backend dedupes by event id).
4. **Drain jobs**: `GET /access-control/agent/jobs` (backend marks them RUNNING),
   execute each, then `POST /access-control/agent/jobs/:id/result`.

Reads/sync **always run**. Mutating BioStar calls obey the `dry_run` flag (below).

## Job actions

`SCAN_CARD` · `ENSURE_USER` · `ENROLL_CARD` · `ASSIGN_CARD` ·
`ISSUE_CARD` (composite: ensure user → enroll → assign → grant plan doors) ·
`REVOKE_CARD` · `GRANT_ACCESS` · `REVOKE_ACCESS` · `SYNC_INVENTORY` · `SYNC_EVENTS`.

## DRY RUN (default ON — safe by default)

`dry_run` comes from the backend setting `integrations.biostar.dry_run`
(**default `true`**).

- **`dry_run = true`** (default): the agent **LOGS** each intended BioStar write
  (`DRY_RUN would …`) and posts a `DONE` result with `{ "dryRun": true }`
  **without calling any mutating BioStar endpoint**. Reads/scans still run.
- **`dry_run = false`**: mutations actually execute against BioStar.
- `SCAN_CARD` is treated as a read (it reads a card off a reader) and runs in both
  modes.

There is also a **local hard override** `FORCE_DRY_RUN=true` (env) that forces
dry-run on this box even if the backend says `false` — useful for a cautious
first deploy.

## Requirements

- **Node 18+** (uses the global `fetch` for backend calls and `node:https` for the
  self-signed BioStar TLS). **No external npm runtime dependencies** — only
  `typescript` + `@types/node` as dev deps for the build.

## Environment variables

| Var | Required | Default | Meaning |
|---|---|---|---|
| `BACKEND_URL` | **yes** | — | Cloud backend base URL incl. `/api`, e.g. `https://api.vision7.sa/api` |
| `AGENT_KEY` | **yes** | — | Shared secret, sent as `X-Agent-Key`. Must match `integrations.biostar.agent_key` in CRM settings |
| `POLL_INTERVAL_MS` | no | `15000` | Loop cadence |
| `EVENT_PAGE_SIZE` | no | `100` | Max events per sync pass |
| `FORCE_DRY_RUN` | no | `false` | Local override to force dry-run regardless of backend |
| `LOG_LEVEL` | no | `info` | `debug` / `info` / `warn` / `error` |

BioStar host/port/login/password live in the **backend settings**, not here.

## Run on the premises machine

```bash
# 1. Install (dev deps only; no runtime deps)
cd biostar-agent
npm install

# 2. Build TypeScript -> dist/
npm run build

# 3. Configure
cp .env.example .env        # then edit BACKEND_URL + AGENT_KEY
#   (or export the two vars in the environment / service manager)

# 4. Start
#    Linux/macOS:
BACKEND_URL=https://api.vision7.sa/api AGENT_KEY=xxxxx npm start
#    Windows PowerShell:
#    $env:BACKEND_URL="https://api.vision7.sa/api"; $env:AGENT_KEY="xxxxx"; npm start
```

### Run it as a long-lived service

Any process manager works since the agent is just `node dist/index.js`:

- **pm2**: `pm2 start dist/index.js --name vision7-biostar-agent` (set the env in
  an `ecosystem.config.cjs` or the shell first).
- **systemd**: an `ExecStart=/usr/bin/node /opt/biostar-agent/dist/index.js` unit
  with `Environment=BACKEND_URL=… AGENT_KEY=…` and `Restart=always`.
- **Windows**: NSSM or a Scheduled Task running `node dist\index.js`.

The agent handles `SIGINT`/`SIGTERM` for a clean stop and is self-healing: a
backend or BioStar outage is logged and retried on the next cycle — it never
crashes the loop.

## Dev / typecheck

```bash
npm run typecheck   # tsc --noEmit  (CI gate)
npm run build       # emit dist/
npm run dev         # run from src/ via node --experimental-strip-types
```

## Source layout

| File | Role |
|---|---|
| `src/index.ts` | Entry + main poll loop (config reload, sync, job drain) |
| `src/env.ts` | Env parsing + required-var guard |
| `src/backend.ts` | Cloud backend client (X-Agent-Key, all agent-facing routes) |
| `src/biostar.ts` | BioStar 2 client (login/session, reads + writes) |
| `src/http.ts` | `node:https` request helper with TLS verification off (self-signed) |
| `src/actions.ts` | Job actions + **dry-run gating** for every mutation |
| `src/jobs.ts` | Job dispatch (payload → action) + result post-back |
| `src/sync.ts` | Inventory + event normalisation/push |
| `src/log.ts` | Tiny structured logger |
| `src/types.ts` | Shared contract + BioStar wire types |

## Known gaps / assumptions

- **TLS verification is disabled** for BioStar (self-signed cert) — safe only
  because the agent sits on the same LAN. Do not point `host` at anything off-LAN.
- **Door → access-group mapping** (`resolveAccessGroupIds` in `actions.ts`) is a
  conservative heuristic (match access-group whose name contains the door id, else
  pass the door ids through). Real BioStar grants are per **access group**, not per
  door; if your site models access differently, refine this mapping (it is the one
  spot that needs site-specific tuning). It is read-only, so it is safe to run in
  dry-run for accurate logging.
- **Event GRANTED/DENIED classification** uses an event-code-prefix heuristic
  (`4xxx` = granted, `5xxx/6xxx` = denied). The raw event is always forwarded in
  `raw`, so the backend can re-derive the result authoritatively if needed.
- **BioStar field shapes vary by firmware.** The client defensively reads both flat
  and collection-wrapped response variants; verify against your appliance before
  flipping `dry_run` off.
- The agent intentionally does **not** persist the event watermark to disk — on
  restart it re-scans the last ~24h (backend dedupes by event id, so this is safe).
```
