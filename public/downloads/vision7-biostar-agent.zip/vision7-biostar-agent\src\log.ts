/** Minimal structured logger (no deps). */

type Level = "debug" | "info" | "warn" | "error";

const LEVELS: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };
const THRESHOLD = LEVELS[(process.env.LOG_LEVEL as Level) ?? "info"] ?? LEVELS.info;

function emit(level: Level, msg: string, extra?: unknown): void {
  if (LEVELS[level] < THRESHOLD) return;
  const ts = new Date().toISOString();
  const line = `[${ts}] ${level.toUpperCase().padEnd(5)} ${msg}`;
  if (extra === undefined) {
    console.log(line);
  } else {
    let rendered: string;
    try {
      rendered = typeof extra === "string" ? extra : JSON.stringify(extra);
    } catch {
      rendered = String(extra);
    }
    console.log(`${line} ${rendered}`);
  }
}

export const log = {
  debug: (msg: string, extra?: unknown) => emit("debug", msg, extra),
  info: (msg: string, extra?: unknown) => emit("info", msg, extra),
  warn: (msg: string, extra?: unknown) => emit("warn", msg, extra),
  error: (msg: string, extra?: unknown) => emit("error", msg, extra),
  /** Highlight an intended-but-skipped BioStar write in DRY_RUN. */
  dryRun: (action: string, detail?: unknown) =>
    emit("info", `DRY_RUN would ${action}`, detail),
};
