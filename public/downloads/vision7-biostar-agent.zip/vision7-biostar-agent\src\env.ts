import { log } from "./log.js";

/**
 * Process environment for the agent. Only two are required:
 *  - BACKEND_URL : base URL of the Vision7 cloud backend, e.g. https://api.vision7.sa/api
 *  - AGENT_KEY   : shared secret sent as X-Agent-Key on every agent-facing call.
 * Everything else has sane defaults.
 */
export interface Env {
  backendUrl: string;
  agentKey: string;
  /** Poll interval in ms for the main loop. */
  pollIntervalMs: number;
  /** Hard override: force dry-run regardless of backend config. */
  forceDryRun: boolean;
  /** Max events fetched per SYNC_EVENTS pass. */
  eventPageSize: number;
}

function required(name: string): string {
  const v = process.env[name];
  if (!v || !v.trim()) {
    log.error(`Missing required env var ${name}`);
    process.exit(1);
  }
  return v.trim();
}

export function loadEnv(): Env {
  const backendUrl = required("BACKEND_URL").replace(/\/+$/, "");
  const agentKey = required("AGENT_KEY");

  const pollIntervalMs = Number(process.env.POLL_INTERVAL_MS ?? "15000");
  const eventPageSize = Number(process.env.EVENT_PAGE_SIZE ?? "100");
  const forceDryRun = /^(1|true|yes)$/i.test(process.env.FORCE_DRY_RUN ?? "");

  return {
    backendUrl,
    agentKey,
    pollIntervalMs: Number.isFinite(pollIntervalMs) && pollIntervalMs > 0 ? pollIntervalMs : 15000,
    eventPageSize: Number.isFinite(eventPageSize) && eventPageSize > 0 ? eventPageSize : 100,
    forceDryRun,
  };
}
