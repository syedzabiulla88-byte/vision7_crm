import type {
  AgentConfig,
  BiostarDevice,
  BiostarDoor,
  BiostarEvent,
  ScanResult,
} from "./types.js";
import { httpRequest } from "./http.js";
import { log } from "./log.js";

/** Collection envelope BioStar 2 wraps list responses in. */
interface Collection<T> {
  total?: number | string;
  rows?: T[];
}

/**
 * Thin client for the BioStar 2 local API.
 *
 * Auth: POST /api/login {User:{login_id,password}} -> response carries a
 * `bs-session-id` response header which must be echoed on every later call.
 * The cert is self-signed, so TLS verification is disabled (insecureTLS).
 * This is acceptable ONLY because the agent runs on the same LAN as the
 * controller.
 */
export class BiostarClient {
  private readonly base: string;
  private sessionId: string | null = null;

  constructor(private readonly cfg: AgentConfig) {
    const port = cfg.port?.trim() || "443";
    this.base = `https://${cfg.host}:${port}/api`;
  }

  /** Authenticate and capture the bs-session-id header. */
  async login(): Promise<void> {
    const res = await httpRequest(`${this.base}/login`, {
      method: "POST",
      insecureTLS: true,
      timeoutMs: 15000,
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ User: { login_id: this.cfg.login_id, password: this.cfg.password } }),
    });

    const sid = res.headers.get("bs-session-id");
    if (!sid) {
      const text = await res.text();
      throw new Error(`BioStar login returned no bs-session-id (status ${res.status}) ${text.slice(0, 200)}`);
    }
    this.sessionId = sid;
    log.info("BioStar login OK");
  }

  /** Authenticated JSON call with one transparent re-login on 401. */
  private async call<T>(method: string, path: string, body?: unknown): Promise<T> {
    if (!this.sessionId) await this.login();

    const doFetch = () =>
      httpRequest(`${this.base}${path}`, {
        method,
        insecureTLS: true,
        timeoutMs: 20000,
        headers: {
          Accept: "application/json",
          ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
          ...(this.sessionId ? { "bs-session-id": this.sessionId } : {}),
        },
        body: body === undefined ? undefined : JSON.stringify(body),
      });

    let res = await doFetch();
    if (res.status === 401) {
      log.warn("BioStar session expired, re-logging in");
      this.sessionId = null;
      await this.login();
      res = await doFetch();
    }

    const text = await res.text();
    if (res.status < 200 || res.status >= 300) {
      throw new Error(`BioStar ${method} ${path} -> ${res.status} ${text.slice(0, 300)}`);
    }
    if (!text) return undefined as unknown as T;
    return JSON.parse(text) as T;
  }

  /* ---------------- reads (always run, even in dry-run) ---------------- */

  async getDevices(): Promise<BiostarDevice[]> {
    const out = await this.call<{ DeviceCollection?: Collection<BiostarDevice> }>("GET", "/devices");
    return out.DeviceCollection?.rows ?? [];
  }

  async getDoors(): Promise<BiostarDoor[]> {
    const out = await this.call<{ DoorCollection?: Collection<BiostarDoor> }>("GET", "/doors");
    return out.DoorCollection?.rows ?? [];
  }

  /** Search door events since a given ISO timestamp. */
  async searchEvents(sinceIso: string, limit: number): Promise<BiostarEvent[]> {
    const body = {
      Query: {
        limit,
        conditions: [{ column: "datetime", operator: 3 /* >= */, values: [sinceIso] }],
        orders: [{ column: "datetime", descending: false }],
      },
    };
    const out = await this.call<{ EventCollection?: Collection<BiostarEvent> }>(
      "POST",
      "/events/search",
      body,
    );
    return out.EventCollection?.rows ?? [];
  }

  /* ---------------- writes (gated by dry-run at the action layer) -------- */

  /** Trigger a card scan on a reader/device; returns the read card. */
  async scanCard(readerId: string): Promise<ScanResult> {
    const out = await this.call<{ CardCollection?: { rows?: ScanResult[] } } & ScanResult>(
      "POST",
      `/devices/${encodeURIComponent(readerId)}/scan_card`,
      {},
    );
    // Firmware variance: either a flat object or wrapped in a collection.
    if (out.CardCollection?.rows?.[0]) return out.CardCollection.rows[0];
    return { card_type: out.card_type, card_id: out.card_id, wiegand_format_id: out.wiegand_format_id };
  }

  /** Rename a device (cosmetic). Minimal PUT — verified to work without the full object. */
  async renameDevice(id: string, name: string): Promise<void> {
    await this.call("PUT", `/devices/${encodeURIComponent(id)}`, { Device: { id, name } });
  }

  /** Enroll a card record; returns the new BioStar card id. */
  async enrollCard(card: { card_id: string; card_type?: string; wiegand_format_id?: string }): Promise<string> {
    const out = await this.call<{ Card?: { id?: string }; id?: string }>("POST", "/cards", {
      Card: {
        card_id: card.card_id,
        ...(card.card_type ? { card_type: { id: card.card_type } } : {}),
        ...(card.wiegand_format_id ? { wiegand_format_id: { id: card.wiegand_format_id } } : {}),
      },
    });
    const id = out.Card?.id ?? out.id;
    if (!id) throw new Error("BioStar enrollCard returned no card id");
    return id;
  }

  /** Ensure a BioStar user exists; create if missing. Returns user id. */
  async ensureUser(userId: string | undefined, name: string): Promise<string> {
    if (userId) {
      try {
        await this.call("GET", `/users/${encodeURIComponent(userId)}`);
        return userId;
      } catch {
        // fall through to create
      }
    }
    const out = await this.call<{ User?: { user_id?: string; id?: string } }>("POST", "/users", {
      User: { name, ...(userId ? { login_id: userId } : {}) },
    });
    const created = out.User?.user_id ?? out.User?.id;
    if (!created) throw new Error("BioStar ensureUser returned no user id");
    return created;
  }

  /** Assign an enrolled card to a user. */
  async assignCard(userId: string, biostarCardId: string): Promise<void> {
    await this.call("PUT", `/users/${encodeURIComponent(userId)}`, {
      User: { cards: [{ id: biostarCardId }] },
    });
  }

  /** Remove all cards from a user (revoke). */
  async clearUserCards(userId: string): Promise<void> {
    await this.call("PUT", `/users/${encodeURIComponent(userId)}`, {
      User: { cards: [] },
    });
  }

  /** Add a user to the given access groups. */
  async grantAccessGroups(userId: string, accessGroupIds: string[]): Promise<void> {
    if (accessGroupIds.length === 0) return;
    await this.call("PUT", `/users/${encodeURIComponent(userId)}`, {
      User: { access_groups: accessGroupIds.map((id) => ({ id })) },
    });
  }

  /** Replace a user's access groups with the empty set (revoke all). */
  async revokeAccessGroups(userId: string): Promise<void> {
    await this.call("PUT", `/users/${encodeURIComponent(userId)}`, {
      User: { access_groups: [] },
    });
  }

  /** Look up access groups so we can map doors -> group ids. */
  async getAccessGroups(): Promise<Array<{ id: string; name?: string }>> {
    const out = await this.call<{ AccessGroupCollection?: Collection<{ id: string; name?: string }> }>(
      "GET",
      "/access_groups",
    );
    return out.AccessGroupCollection?.rows ?? [];
  }
}
