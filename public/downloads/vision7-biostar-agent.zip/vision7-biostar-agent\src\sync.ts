import type { BackendClient } from "./backend.js";
import type { BiostarClient } from "./biostar.js";
import type { BiostarEvent, InventoryPayload, NormalisedEvent } from "./types.js";
import type { Env } from "./env.js";
import { log } from "./log.js";

/** Pull device + door inventory from BioStar and push to the backend cache. */
export async function syncInventory(biostar: BiostarClient, backend: BackendClient): Promise<void> {
  const [devices, doors] = await Promise.all([biostar.getDevices(), biostar.getDoors()]);

  const payload: InventoryPayload = {
    devices: devices.map((d) => ({
      id: String(d.id),
      name: d.name,
      deviceType: d.device_type,
      status: d.status,
      ip: d.ip,
    })),
    doors: doors.map((d) => ({
      id: String(d.id),
      name: d.name,
      deviceId: d.device_id ? String(d.device_id) : undefined,
    })),
  };

  await backend.syncInventory(payload);
  const online = payload.devices.filter((d) => d.status === "1").length;
  log.info(`inventory synced: ${payload.devices.length} devices (${online} online), ${payload.doors.length} doors`);
}

function asId(v: unknown): string | undefined {
  if (v == null) return undefined;
  if (typeof v === "string") return v;
  if (typeof v === "number") return String(v);
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    const cand = o.user_id ?? o.id ?? o.code;
    return cand == null ? undefined : String(cand);
  }
  return undefined;
}

/** GRANTED event codes are commonly in the 4xxx range; DENIED in 5xxx/6xxx. */
function classifyResult(ev: BiostarEvent): "GRANTED" | "DENIED" | undefined {
  const code = asId(ev.event_type_id);
  if (!code) return undefined;
  // Heuristic per BioStar 2 event taxonomy; backend may refine.
  if (/^4/.test(code)) return "GRANTED";
  if (/^(5|6)/.test(code)) return "DENIED";
  return undefined;
}

export function normaliseEvent(ev: BiostarEvent): NormalisedEvent {
  const biostarEventId = ev.id != null ? String(ev.id) : ev.index != null ? String(ev.index) : undefined;
  return {
    biostarEventId,
    biostarUserId: asId(ev.user_id),
    doorId: asId(ev.door_id),
    doorName: ev.door_name,
    result: classifyResult(ev),
    at: ev.datetime ?? new Date().toISOString(),
    raw: ev,
  };
}

/**
 * Pull events newer than the watermark and push them. Returns the new
 * watermark (max event datetime seen) so the caller can advance it.
 */
export async function syncEvents(
  biostar: BiostarClient,
  backend: BackendClient,
  env: Env,
  sinceIso: string,
): Promise<string> {
  const events = await biostar.searchEvents(sinceIso, env.eventPageSize);
  if (events.length === 0) return sinceIso;

  const normalised = events.map(normaliseEvent);
  await backend.syncEvents(normalised);

  let maxAt = sinceIso;
  for (const e of normalised) {
    if (e.at > maxAt) maxAt = e.at;
  }
  log.info(`events synced: ${normalised.length} (watermark -> ${maxAt})`);
  return maxAt;
}
