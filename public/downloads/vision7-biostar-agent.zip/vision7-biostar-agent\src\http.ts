import https from "node:https";
import { URL } from "node:url";

/**
 * Minimal https request helper built on node:https so we can disable TLS
 * verification for BioStar's self-signed cert WITHOUT any external dependency.
 *
 * Node's global fetch (undici) does NOT honour a `node:https.Agent` passed as
 * `agent`; it requires an undici `dispatcher`, which is not a stable public,
 * dependency-free API. Using node:https directly is the reliable no-dep path.
 */

export interface HttpResponse {
  status: number;
  /** Lower-cased header lookup, mirroring fetch's res.headers.get(). */
  headers: { get(name: string): string | null };
  text(): Promise<string>;
}

export interface HttpRequestOptions {
  method: string;
  headers?: Record<string, string>;
  body?: string;
  /** When true, accept self-signed / mismatched certs (LAN appliance only). */
  insecureTLS?: boolean;
  /** Per-request timeout in ms. */
  timeoutMs?: number;
}

export function httpRequest(rawUrl: string, opts: HttpRequestOptions): Promise<HttpResponse> {
  const url = new URL(rawUrl);
  const payload = opts.body;

  const requestOptions: https.RequestOptions = {
    method: opts.method,
    hostname: url.hostname,
    port: url.port || 443,
    path: `${url.pathname}${url.search}`,
    headers: {
      ...(opts.headers ?? {}),
      ...(payload !== undefined ? { "Content-Length": Buffer.byteLength(payload).toString() } : {}),
    },
    rejectUnauthorized: opts.insecureTLS ? false : true,
  };

  return new Promise<HttpResponse>((resolve, reject) => {
    const req = https.request(requestOptions, (res) => {
      const chunks: Buffer[] = [];
      res.on("data", (c: Buffer) => chunks.push(c));
      res.on("end", () => {
        const bodyText = Buffer.concat(chunks).toString("utf8");
        resolve({
          status: res.statusCode ?? 0,
          headers: {
            get(name: string): string | null {
              const v = res.headers[name.toLowerCase()];
              if (v === undefined) return null;
              return Array.isArray(v) ? v.join(", ") : v;
            },
          },
          text: async () => bodyText,
        });
      });
    });

    req.on("error", reject);
    if (opts.timeoutMs) {
      req.setTimeout(opts.timeoutMs, () => {
        req.destroy(new Error(`request timeout after ${opts.timeoutMs}ms: ${opts.method} ${rawUrl}`));
      });
    }
    if (payload !== undefined) req.write(payload);
    req.end();
  });
}
