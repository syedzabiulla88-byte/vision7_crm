@echo off
cd /d "%~dp0"
title Vision7 BioStar Agent
if not exist config.env (
  echo  [!] config.env not found. Copy config.env.example to config.env and edit it.
  pause & exit /b 1
)
echo  Vision7 BioStar agent running.  Close this window to stop.
echo ------------------------------------------------------------
node dist\index.js
echo ------------------------------------------------------------
echo  Agent stopped. Press any key to close.
pause >nul
