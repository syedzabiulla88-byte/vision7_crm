import type { Env } from "./env.js";
import type { AgentConfig, InventoryPayload, Job, JobResult, NormalisedEvent } from "./types.js";
import { log } from "./log.js";

/**
 * Client for the Vision7 cloud backend (the BRAIN).
 * All calls are outbound HTTPS and authenticate with the X-Agent-Key header.
 * The backend never talks to BioStar; it only stores config, queues jobs and
 * caches inventory/events.
 */
export class BackendClient {
  private readonly base: string;
  private readonly agentKey: string;

  constructor(env: Env) {
    this.base = env.backendUrl;
    this.agentKey = env.agentKey;
  }

  private async call<T>(
    method: string,
    path: string,
    body?: unknown,
  ): Promise<T> {
    const url = `${this.base}${path}`;
    const headers: Record<string, string> = {
      "X-Agent-Key": this.agentKey,
      Accept: "application/json",
    };
    if (body !== undefined) headers["Content-Type"] = "application/json";

    const res = await fetch(url, {
      method,
      headers,
      body: body === undefined ? undefined : JSON.stringify(body),
    });

    const text = await res.text();
    if (!res.ok) {
      throw new Error(`backend ${method} ${path} -> ${res.status} ${text.slice(0, 300)}`);
    }
    if (!text) return undefined as unknown as T;
    try {
      const parsed = JSON.parse(text);
      // The cloud backend wraps every response in { success, data }. Unwrap it
      // so callers receive the actual payload (config object, jobs array, ...).
      if (parsed && typeof parsed === "object" && "success" in parsed && "data" in parsed) {
        return (parsed as { data: T }).data;
      }
      return parsed as T;
    } catch {
      return text as unknown as T;
    }
  }

  /** Fetch the BioStar connection config (incl. decrypted password). */
  getConfig(): Promise<AgentConfig> {
    return this.call<AgentConfig>("GET", "/access-control/agent/config");
  }

  /** Claim + return the pending jobs (backend marks them RUNNING). */
  async claimJobs(): Promise<Job[]> {
    const out = await this.call<Job[] | { jobs?: Job[] }>(
      "GET",
      "/access-control/agent/jobs",
    );
    if (Array.isArray(out)) return out;
    return out?.jobs ?? [];
  }

  /** Report the outcome of a job. */
  postJobResult(jobId: string, result: JobResult): Promise<void> {
    return this.call<void>("POST", `/access-control/agent/jobs/${encodeURIComponent(jobId)}/result`, result);
  }

  /** Push the latest inventory snapshot; also serves as heartbeat. */
  syncInventory(payload: InventoryPayload): Promise<void> {
    return this.call<void>("POST", "/access-control/agent/sync/inventory", payload);
  }

  /** Push new door events (backend dedupes by biostarEventId). */
  syncEvents(events: NormalisedEvent[]): Promise<void> {
    if (events.length === 0) return Promise.resolve();
    return this.call<void>("POST", "/access-control/agent/sync/events", { events });
  }

  /** Best-effort: never let a backend hiccup crash the loop. */
  async safe<T>(label: string, fn: () => Promise<T>): Promise<T | undefined> {
    try {
      return await fn();
    } catch (err) {
      log.error(`backend ${label} failed`, err instanceof Error ? err.message : String(err));
      return undefined;
    }
  }
}
