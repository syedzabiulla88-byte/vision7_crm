import { loadConfigFile } from "./config-file.js";
loadConfigFile(); // populate process.env from config.env before anything reads it

import { loadEnv } from "./env.js";
import { BackendClient } from "./backend.js";
import { BiostarClient } from "./biostar.js";
import { Actions } from "./actions.js";
import { runJob } from "./jobs.js";
import { syncInventory, syncEvents } from "./sync.js";
import type { AgentConfig } from "./types.js";
import { log } from "./log.js";

const env = loadEnv();
const backend = new BackendClient(env);

/** Sleep helper for the loop cadence. */
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

let stopping = false;
process.on("SIGINT", () => {
  log.info("SIGINT received, shutting down after current cycle");
  stopping = true;
});
process.on("SIGTERM", () => {
  log.info("SIGTERM received, shutting down after current cycle");
  stopping = true;
});

/** Apply FORCE_DRY_RUN env override on top of backend config. */
function effectiveConfig(cfg: AgentConfig): AgentConfig {
  if (env.forceDryRun && cfg.dry_run !== true) {
    log.warn("FORCE_DRY_RUN env set -> overriding backend dry_run to true");
    return { ...cfg, dry_run: true };
  }
  return cfg;
}

async function cycle(state: {
  biostar: BiostarClient | null;
  cfgKey: string;
  watermark: { value: string };
}): Promise<void> {
  // 1. (Re)load config each cycle so settings changes in the CRM take effect.
  const rawCfg = await backend.safe("getConfig", () => backend.getConfig());
  if (!rawCfg) return; // backend unreachable -> skip cycle, try again next tick

  if (!rawCfg.enabled) {
    log.info("integration disabled in backend config; idle");
    state.biostar = null;
    return;
  }
  if (!rawCfg.host) {
    log.warn("config enabled but host empty; idle");
    return;
  }

  const cfg = effectiveConfig(rawCfg);
  const cfgKey = `${cfg.host}:${cfg.port}:${cfg.login_id}`;
  if (!state.biostar || state.cfgKey !== cfgKey) {
    log.info(`(re)connecting BioStar client for ${cfg.host}:${cfg.port} (dry_run=${cfg.dry_run !== false})`);
    state.biostar = new BiostarClient(cfg);
    state.cfgKey = cfgKey;
  }

  const biostar = state.biostar;
  const actions = new Actions(biostar, cfg);

  // 2. Inventory sync (also serves as heartbeat). Reads always run.
  await backend.safe("syncInventory", () => syncInventory(biostar, backend));

  // 3. Event sync. Reads always run.
  await backend.safe("syncEvents", async () => {
    state.watermark.value = await syncEvents(biostar, backend, env, state.watermark.value);
  });

  // 4. Drain queued jobs.
  const jobs = (await backend.safe("claimJobs", () => backend.claimJobs())) ?? [];
  if (jobs.length > 0) log.info(`claimed ${jobs.length} job(s)`);
  for (const job of jobs) {
    if (stopping) break;
    await runJob(job, { actions, biostar, backend, env, watermark: state.watermark });
  }
}

async function main(): Promise<void> {
  log.info("Vision7 BioStar agent starting", {
    backendUrl: env.backendUrl,
    pollIntervalMs: env.pollIntervalMs,
    forceDryRun: env.forceDryRun,
  });

  // Watermark defaults to ~24h ago so the first events pull has a sane window.
  const watermark = { value: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() };
  const state = { biostar: null as BiostarClient | null, cfgKey: "", watermark };

  while (!stopping) {
    const started = Date.now();
    try {
      await cycle(state);
    } catch (err) {
      // Top-level guard: a thrown error must never kill the loop.
      log.error("cycle error", err instanceof Error ? err.stack ?? err.message : String(err));
    }
    const elapsed = Date.now() - started;
    const wait = Math.max(0, env.pollIntervalMs - elapsed);
    if (!stopping) await sleep(wait);
  }

  log.info("agent stopped");
}

main().catch((err) => {
  log.error("fatal", err instanceof Error ? err.stack ?? err.message : String(err));
  process.exit(1);
});
