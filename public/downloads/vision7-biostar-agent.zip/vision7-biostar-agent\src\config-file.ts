import { readFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";

/**
 * Loads a plain KEY=VALUE `config.env` file sitting next to the agent, so an
 * operator can configure it by editing a text file instead of setting OS
 * environment variables. Real environment variables (if already set) win.
 *
 * Looked for in: the current working directory, and the folder the executable
 * lives in (so it works both as `node dist/index.js` and as the packaged .exe).
 */
function loadFrom(file: string): boolean {
  if (!existsSync(file)) return false;
  let text: string;
  try {
    text = readFileSync(file, "utf8");
  } catch {
    return false;
  }
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq < 0) continue;
    const key = line.slice(0, eq).trim();
    let val = line.slice(eq + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    if (key && process.env[key] === undefined) process.env[key] = val;
  }
  return true;
}

export function loadConfigFile(): void {
  const candidates = [
    join(process.cwd(), "config.env"),
    join(dirname(process.execPath), "config.env"),
  ];
  for (const c of candidates) {
    if (loadFrom(c)) return;
  }
}
