@echo off
cd /d "%~dp0"
schtasks /Create /TN "Vision7BioStarAgent" /SC ONLOGON /F /TR "\"%~dp0start-headless.cmd\""
echo.
echo  Installed: the agent will auto-start when you log in to Windows.
echo  Start it now (without rebooting): double-click  start.cmd
echo  Remove it: run  uninstall-autostart.cmd
echo  For an always-on SERVER (start at boot, no login), see README ("always-on server").
pause
