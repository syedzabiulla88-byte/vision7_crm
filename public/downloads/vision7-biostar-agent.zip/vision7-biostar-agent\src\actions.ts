import type { BiostarClient } from "./biostar.js";
import type { AgentConfig, Subject } from "./types.js";
import { log } from "./log.js";

/**
 * The action layer. Each method maps to a job type. This is the ONLY place
 * that enforces dry-run for mutating BioStar calls:
 *
 *   - reads / scans-as-reads always execute,
 *   - mutations execute ONLY when cfg.dry_run === false.
 *
 * In dry-run, a mutation is logged and a {dryRun:true} marker is folded into
 * the returned result so the backend can record that nothing was written.
 */
export class Actions {
  constructor(
    private readonly biostar: BiostarClient,
    private readonly cfg: AgentConfig,
  ) {}

  private get dry(): boolean {
    return this.cfg.dry_run !== false;
  }

  /** SCAN_CARD — a READ from a reader; always runs (even in dry-run). */
  async scanCard(readerId?: string): Promise<Record<string, unknown>> {
    const reader = readerId || this.cfg.enrollment_reader_id;
    if (!reader) throw new Error("scanCard: no readerId and no enrollment_reader_id configured");
    log.info(`scanCard on reader ${reader}`);
    let scan;
    try {
      scan = await this.biostar.scanCard(reader);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      // BioStar code 1003 = "device did not respond in the scan window" — almost
      // always no card was tapped in time (or a slow/cross-subnet reader).
      if (/1003|not respond|timeout/i.test(msg)) {
        throw new Error("No card detected — present a card on the reader within a few seconds and try again. (If it keeps timing out, the reader may be slow/unreachable.)");
      }
      throw err;
    }
    if (!scan.card_id) {
      throw new Error("No card detected — present a card on the reader and try again.");
    }
    return {
      readerId: reader,
      cardId: scan.card_id ?? null,
      cardType: scan.card_type ?? null,
      wiegandFormatId: scan.wiegand_format_id ?? null,
    };
  }

  /** RENAME_DEVICE — cosmetic device rename. NOT gated by dry-run (no access impact). */
  async renameDevice(args: { deviceId: string; name: string }): Promise<Record<string, unknown>> {
    if (!args.deviceId || !args.name) throw new Error("renameDevice: deviceId and name required");
    await this.biostar.renameDevice(args.deviceId, args.name);
    return { renamed: true, deviceId: args.deviceId, name: args.name };
  }

  /** ENSURE_USER — create the BioStar user if missing. Mutation. */
  async ensureUser(subject: Subject): Promise<Record<string, unknown>> {
    const name = subject.name || `${subject.subjectKind}:${subject.subjectId}`;
    if (this.dry) {
      log.dryRun("ensure BioStar user", { subject: name, existing: subject.biostarUserId ?? null });
      return { dryRun: true, biostarUserId: subject.biostarUserId ?? null, name };
    }
    const userId = await this.biostar.ensureUser(subject.biostarUserId, name);
    return { biostarUserId: userId, name };
  }

  /** ENROLL_CARD — register a card record in BioStar. Mutation. */
  async enrollCard(card: { cardId: string; cardType?: string; wiegandFormatId?: string }): Promise<Record<string, unknown>> {
    if (!card.cardId) throw new Error("enrollCard: cardId required");
    if (this.dry) {
      log.dryRun("enroll card", card);
      return { dryRun: true, biostarCardId: null, cardId: card.cardId };
    }
    const biostarCardId = await this.biostar.enrollCard({
      card_id: card.cardId,
      card_type: card.cardType,
      wiegand_format_id: card.wiegandFormatId,
    });
    return { biostarCardId, cardId: card.cardId };
  }

  /** ASSIGN_CARD — bind an enrolled card to a user. Mutation. */
  async assignCard(args: { biostarUserId: string; biostarCardId: string }): Promise<Record<string, unknown>> {
    if (!args.biostarUserId || !args.biostarCardId) {
      throw new Error("assignCard: biostarUserId and biostarCardId required");
    }
    if (this.dry) {
      log.dryRun("assign card to user", args);
      return { dryRun: true, ...args };
    }
    await this.biostar.assignCard(args.biostarUserId, args.biostarCardId);
    return { assigned: true, ...args };
  }

  /** GRANT_ACCESS — add user to the access groups bound to the given doors. Mutation. */
  async grantAccess(args: { biostarUserId: string; doorIds: string[] }): Promise<Record<string, unknown>> {
    if (!args.biostarUserId) throw new Error("grantAccess: biostarUserId required");
    const groupIds = await this.resolveAccessGroupIds(args.doorIds ?? []);
    if (this.dry) {
      log.dryRun("grant access", { ...args, resolvedAccessGroupIds: groupIds });
      return { dryRun: true, ...args, resolvedAccessGroupIds: groupIds };
    }
    await this.biostar.grantAccessGroups(args.biostarUserId, groupIds);
    return { granted: true, biostarUserId: args.biostarUserId, accessGroupIds: groupIds };
  }

  /** REVOKE_ACCESS — strip a user's access groups. Mutation. */
  async revokeAccess(args: { biostarUserId: string }): Promise<Record<string, unknown>> {
    if (!args.biostarUserId) throw new Error("revokeAccess: biostarUserId required");
    if (this.dry) {
      log.dryRun("revoke access", args);
      return { dryRun: true, ...args };
    }
    await this.biostar.revokeAccessGroups(args.biostarUserId);
    return { revoked: true, ...args };
  }

  /** REVOKE_CARD — clear the user's cards (and access). Mutation. */
  async revokeCard(args: { biostarUserId: string; biostarCardId?: string }): Promise<Record<string, unknown>> {
    if (!args.biostarUserId) throw new Error("revokeCard: biostarUserId required");
    if (this.dry) {
      log.dryRun("revoke card", args);
      return { dryRun: true, ...args };
    }
    await this.biostar.clearUserCards(args.biostarUserId);
    return { revoked: true, ...args };
  }

  /**
   * ISSUE_CARD — composite: ensure user -> enroll card -> assign -> grant doors.
   * The whole composite is gated by dry-run; in dry-run every sub-step is
   * logged and skipped.
   */
  async issueCard(args: {
    subject: Subject;
    cardId: string;
    cardType?: string;
    wiegandFormatId?: string;
    doorIds?: string[];
  }): Promise<Record<string, unknown>> {
    if (!args.cardId) throw new Error("issueCard: cardId required");
    const name = args.subject.name || `${args.subject.subjectKind}:${args.subject.subjectId}`;
    const doorIds = args.doorIds ?? [];

    if (this.dry) {
      const groupIds = await this.resolveAccessGroupIds(doorIds);
      log.dryRun("issue card (ensureUser+enroll+assign+grant)", {
        subject: name,
        cardId: args.cardId,
        doorIds,
        resolvedAccessGroupIds: groupIds,
      });
      return {
        dryRun: true,
        subject: { subjectKind: args.subject.subjectKind, subjectId: args.subject.subjectId, name },
        biostarUserId: args.subject.biostarUserId ?? null,
        biostarCardId: null,
        cardId: args.cardId,
        doorIds,
        resolvedAccessGroupIds: groupIds,
      };
    }

    const biostarUserId = await this.biostar.ensureUser(args.subject.biostarUserId, name);
    const biostarCardId = await this.biostar.enrollCard({
      card_id: args.cardId,
      card_type: args.cardType,
      wiegand_format_id: args.wiegandFormatId,
    });
    await this.biostar.assignCard(biostarUserId, biostarCardId);
    const groupIds = await this.resolveAccessGroupIds(doorIds);
    await this.biostar.grantAccessGroups(biostarUserId, groupIds);

    return {
      biostarUserId,
      biostarCardId,
      cardId: args.cardId,
      doorIds,
      accessGroupIds: groupIds,
    };
  }

  /**
   * Map door ids -> access group ids. BioStar grants are by access group, not
   * by door directly; we match groups whose name references the door, falling
   * back to passing the door ids through unchanged if no mapping is found.
   *
   * This is intentionally conservative and READ-ONLY (getAccessGroups), so it
   * is safe to call in dry-run for accurate logging.
   */
  private async resolveAccessGroupIds(doorIds: string[]): Promise<string[]> {
    if (doorIds.length === 0) return [];
    try {
      const groups = await this.biostar.getAccessGroups();
      const matched = groups
        .filter((g) => doorIds.some((d) => (g.name ?? "").includes(d) || g.id === d))
        .map((g) => g.id);
      // If nothing matched, surface the door ids so the backend/operator can see
      // there is no group mapping yet (a known gap, see README).
      return matched.length > 0 ? matched : doorIds;
    } catch (err) {
      log.warn("resolveAccessGroupIds: could not read access_groups, passing door ids through", err instanceof Error ? err.message : String(err));
      return doorIds;
    }
  }
}
