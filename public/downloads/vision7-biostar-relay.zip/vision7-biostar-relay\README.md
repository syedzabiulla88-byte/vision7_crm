# Vision7 BioStar Relay

A tiny local HTTPS gateway that lets the **Vision7 CRM (browser)** reach the
**LAN-only BioStar 2 API**. It exists for one reason: a browser can't call BioStar
directly — BioStar sends no CORS header and uses a self-signed cert. The relay runs
on a premises machine, the browser calls **it** (CORS-clean), and it forwards to
BioStar server-side (where neither wall applies).

```
CRM (browser) ──HTTPS, CORS-OK──►  THIS RELAY (LAN)  ──HTTPS, cert ignored──►  BioStar 2
```

BioStar credentials live **here** (config.env) — never in the browser or cloud. The
relay logs in and injects the session; the browser just calls `/api/*`.

## Run (Windows)
1. Install **Node 18+** (nodejs.org → LTS).
2. Copy this folder onto a premises PC/server (same LAN as BioStar).
3. Copy `config.env.example` → `config.env` and fill in BioStar host + a login + the
   CRM origin(s). A **dedicated BioStar API user** is recommended.
4. Double-click `start.cmd` (first run installs one dependency).
5. **Trust the relay's cert once per browser:** open `https://<relay-pc-ip>:8443/relay/health`
   in the browser, accept the warning. After that the CRM's calls to the relay work.
6. In **CRM → Settings → BioStar**, set the relay URL to `https://<relay-pc-ip>:8443`
   (+ the RELAY_KEY if you set one) and hit Test connection.

## Endpoints
- `GET /relay/health` → `{ ok, reachable }` (used by the CRM Test connection)
- `* /api/*` → proxied to BioStar with the session injected + CORS headers added

## Notes
- `HTTP_PORT=<port>` (optional) adds a plain-HTTP listener — handy only if you run
  the CRM itself over http on the LAN (then no cert to trust). Cloud CRM (https) must
  use the https port.
- `ALLOWED_ORIGINS` restricts who may call the relay; `RELAY_KEY` adds a shared secret.
- Keep it on a trusted LAN. It holds a BioStar login, so treat the box accordingly.
