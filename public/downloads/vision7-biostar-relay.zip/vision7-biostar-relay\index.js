// ─── Vision7 BioStar Relay ───────────────────────────────────────────────────
//
// A tiny local HTTPS gateway that lets the Vision7 CRM (a browser page) reach the
// LAN-only BioStar 2 API. It exists for ONE reason: a browser cannot call BioStar
// directly — BioStar sends no CORS headers and uses a self-signed cert. This relay
// runs on a machine on the premises LAN, the browser calls IT (CORS-clean), and it
// forwards to BioStar server-side (where neither CORS nor the cert apply).
//
//   CRM (browser) ──HTTPS, CORS-OK──►  THIS RELAY (LAN)  ──HTTPS, cert ignored──►  BioStar 2
//
// BioStar credentials live here (config.env), never in the browser/cloud. The relay
// logs into BioStar and injects the session, so the browser just calls /api/* and
// gets data back — no credentials cross the wire to the browser.

"use strict";

const https = require("node:https");
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

// ── config (config.env next to this file, or real env vars) ──
loadConfigFile();
const CFG = {
  host: (process.env.BIOSTAR_HOST || "").trim(),
  port: (process.env.BIOSTAR_PORT || "443").trim(),
  login: (process.env.BIOSTAR_LOGIN || "").trim(),
  password: process.env.BIOSTAR_PASSWORD || "",
  origins: (process.env.ALLOWED_ORIGINS || "")
    .split(",").map((s) => s.trim()).filter(Boolean),
  relayKey: (process.env.RELAY_KEY || "").trim(),
  listenPort: Number(process.env.PORT || 8443),
  httpPort: process.env.HTTP_PORT ? Number(process.env.HTTP_PORT) : 0,
};

function log(...a) { console.log(new Date().toISOString(), ...a); }

if (!CFG.host || !CFG.login || !CFG.password) {
  console.error("[relay] BIOSTAR_HOST / BIOSTAR_LOGIN / BIOSTAR_PASSWORD are required (set them in config.env). Exiting.");
  process.exit(1);
}

// ── one low-level request to BioStar (self-signed cert ignored) ──
function biostarRequest(method, pathQuery, extraHeaders, body) {
  return new Promise((resolve, reject) => {
    const data =
      body == null ? null : typeof body === "string" || Buffer.isBuffer(body) ? body : JSON.stringify(body);
    const req = https.request(
      {
        host: CFG.host,
        port: CFG.port,
        path: pathQuery,
        method,
        rejectUnauthorized: false, // BioStar self-signed cert — safe: same LAN
        headers: {
          Accept: "application/json",
          ...(data != null ? { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) } : {}),
          ...(extraHeaders || {}),
        },
      },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => resolve({ status: res.statusCode || 0, headers: res.headers, body: Buffer.concat(chunks) }));
      },
    );
    req.on("error", reject);
    if (data != null) req.write(data);
    req.end();
  });
}

// ── BioStar session (login + re-login on 401) ──
let sessionId = null;
async function login() {
  const r = await biostarRequest("POST", "/api/login", {}, { User: { login_id: CFG.login, password: CFG.password } });
  const sid = r.headers["bs-session-id"];
  if (r.status >= 200 && r.status < 300 && sid) { sessionId = String(sid); log("[relay] BioStar login OK"); return true; }
  log("[relay] BioStar login FAILED", r.status, r.body.toString().slice(0, 200));
  return false;
}
async function ensureSession() { if (!sessionId) await login(); return sessionId; }

/** Forward a browser call to BioStar with the injected session, re-login once on 401. */
async function forward(method, pathQuery, body) {
  await ensureSession();
  let r = await biostarRequest(method, pathQuery, { "bs-session-id": sessionId || "" }, body);
  if (r.status === 401) { if (await login()) r = await biostarRequest(method, pathQuery, { "bs-session-id": sessionId || "" }, body); }
  return r;
}

// ── CORS ──
function applyCors(req, res) {
  const origin = req.headers.origin || "";
  const allowed = CFG.origins.length === 0 || CFG.origins.includes(origin);
  if (origin && allowed) res.setHeader("Access-Control-Allow-Origin", origin);
  res.setHeader("Vary", "Origin");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, X-Relay-Key, bs-session-id");
  res.setHeader("Access-Control-Max-Age", "600");
  return allowed;
}
function readBody(req) {
  return new Promise((resolve) => { const c = []; req.on("data", (x) => c.push(x)); req.on("end", () => resolve(Buffer.concat(c))); });
}

// ── HTTPS server (browser-facing) ──
const handle = async (req, res) => {
  const allowed = applyCors(req, res);
  if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }
  if (req.headers.origin && !allowed) { res.writeHead(403); res.end("origin not allowed"); return; }

  try {
    const url = req.url || "/";
    // Health probe for the CRM "Test connection".
    if (url === "/relay/health") {
      const ok = await ensureSession();
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ ok: !!ok, biostar: `${CFG.host}:${CFG.port}`, reachable: !!ok }));
      return;
    }
    // Optional shared key gate.
    if (CFG.relayKey && req.headers["x-relay-key"] !== CFG.relayKey) {
      res.writeHead(401, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Invalid relay key" }));
      return;
    }
    // Proxy BioStar API calls.
    if (url.startsWith("/api/")) {
      const body = ["GET", "HEAD"].includes(req.method) ? null : await readBody(req);
      const r = await forward(req.method, url, body && body.length ? body : null);
      // pass a fresh bs-session-id through if BioStar rotated it
      if (r.headers["bs-session-id"]) res.setHeader("bs-session-id", String(r.headers["bs-session-id"]));
      res.writeHead(r.status, { "Content-Type": r.headers["content-type"] || "application/json" });
      res.end(r.body);
      return;
    }
    res.writeHead(404, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ message: "Not found. Use /relay/health or /api/*" }));
  } catch (err) {
    log("[relay] error", err && err.message);
    res.writeHead(502, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ message: "Relay error: " + (err && err.message) }));
  }
};

const { key, cert } = ensureCert();
https.createServer({ key, cert }, handle).listen(CFG.listenPort, () => {
  log(`[relay] HTTPS on https://0.0.0.0:${CFG.listenPort}  ->  BioStar ${CFG.host}:${CFG.port}`);
  log(`[relay] allowed origins: ${CFG.origins.length ? CFG.origins.join(", ") : "(any)"}`);
});
if (CFG.httpPort) {
  http.createServer(handle).listen(CFG.httpPort, () =>
    log(`[relay] HTTP on http://0.0.0.0:${CFG.httpPort} (for a CRM served over http — no cert needed)`));
}
login().catch(() => {});
process.on("SIGINT", () => process.exit(0));
process.on("SIGTERM", () => process.exit(0));

// ── helpers ──
function loadConfigFile() {
  for (const f of [path.join(process.cwd(), "config.env"), path.join(__dirname, "config.env")]) {
    try {
      if (!fs.existsSync(f)) continue;
      for (const line of fs.readFileSync(f, "utf8").split(/\r?\n/)) {
        const t = line.trim();
        if (!t || t.startsWith("#")) continue;
        const eq = t.indexOf("=");
        if (eq < 0) continue;
        const k = t.slice(0, eq).trim();
        let v = t.slice(eq + 1).trim();
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
        if (k && process.env[k] === undefined) process.env[k] = v;
      }
      return;
    } catch { /* ignore */ }
  }
}

/** Load (or generate once) a self-signed cert for the relay's own HTTPS. */
function ensureCert() {
  const dir = path.join(__dirname, ".cert");
  const keyPath = path.join(dir, "key.pem");
  const certPath = path.join(dir, "cert.pem");
  try {
    if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
      return { key: fs.readFileSync(keyPath), cert: fs.readFileSync(certPath) };
    }
  } catch { /* regenerate */ }
  // generate via the `selfsigned` dep
  const selfsigned = require("selfsigned");
  const pems = selfsigned.generate(
    [{ name: "commonName", value: "vision7-biostar-relay" }],
    { keySize: 2048, days: 3650, algorithm: "sha256" },
  );
  try { fs.mkdirSync(dir, { recursive: true }); fs.writeFileSync(keyPath, pems.private); fs.writeFileSync(certPath, pems.cert); } catch { /* ephemeral ok */ }
  log("[relay] generated a self-signed cert (.cert/) — trust it once per browser");
  return { key: pems.private, cert: pems.cert };
}
