@echo off
cd /d "%~dp0"
title Vision7 BioStar Relay
if not exist config.env goto noconfig
if not exist node_modules call npm install
echo Relay running. Close this window to stop.
node index.js
pause
goto :eof
:noconfig
echo [!] config.env not found. Copy config.env.example to config.env, edit it, then run start.cmd again.
pause
