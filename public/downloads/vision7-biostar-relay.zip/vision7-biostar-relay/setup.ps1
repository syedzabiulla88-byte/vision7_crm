# Writes config.env on THIS machine, from answers typed at this keyboard.
# Nothing typed here is stored anywhere else, and config.env is git-ignored.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

if (Test-Path 'config.env') {
  Write-Host 'config.env already exists. Edit it directly, or delete it and run this again.' -ForegroundColor Yellow
  exit 1
}

$biostarHost = Read-Host 'BioStar server IP  (press Enter for 10.1.100.46)'
if (-not $biostarHost) { $biostarHost = '10.1.100.46' }

$login = Read-Host 'BioStar login ID'
while (-not $login) { $login = Read-Host 'BioStar login ID (required)' }

$secure = Read-Host 'BioStar password (not shown)' -AsSecureString
$pass = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
  [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
while (-not $pass) {
  $secure = Read-Host 'BioStar password (required, not shown)' -AsSecureString
  $pass = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
}

$origin = Read-Host 'CRM address  (press Enter for https://crm.vision7.sa)'
if (-not $origin) { $origin = 'https://crm.vision7.sa' }

# Written verbatim — the relay reads everything after the first "=" literally,
# so a password containing | $ { } " or spaces needs no escaping here.
Set-Content -Path 'config.env' -Encoding ASCII -Value @(
  "BIOSTAR_HOST=$biostarHost",
  'BIOSTAR_PORT=443',
  "BIOSTAR_LOGIN=$login",
  "BIOSTAR_PASSWORD=$pass",
  "ALLOWED_ORIGINS=$origin",
  'PORT=8443',
  'RELAY_KEY='
)

Write-Host ''
Write-Host 'config.env written.' -ForegroundColor Green
Write-Host 'Next: run install-autostart.bat to start the relay and keep it running.'
