@echo off
rem Runs the relay in this window, for testing. For normal use run install-autostart.bat instead.
title Vision7 BioStar Relay (test run)
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  rem The certificate password file is readable only by SYSTEM and elevated
  rem administrators, so an unelevated run cannot start the relay. Re-launch elevated.
  echo Asking for administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

if not exist config.env (
  echo config.env not found. Copy config.env.example to config.env and fill it in first.
  pause
  exit /b 1
)
node index.js
echo.
echo The relay has stopped. Read the message above to see why.
pause
