@echo off
rem Compatibility shim. The first-generation relay was launched with start.cmd, so
rem desktop shortcuts, pinned icons and scheduled tasks on existing installs still
rem point at this filename. Upgrading in place used to leave those pointing at the
rem OLD folder's start.cmd, which reported "config.env not found" and stopped.
rem This hands off to the current scripts instead.
cd /d "%~dp0"
title Vision7 BioStar Relay

net session >nul 2>&1
if errorlevel 1 (
  rem The certificate password file is readable only by SYSTEM and elevated
  rem administrators, so an unelevated run cannot start the relay. Re-launch elevated.
  echo Asking for administrator rights...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)


if not exist config.env (
  echo config.env not found - starting setup so you can enter the BioStar login.
  echo.
  call "%~dp0setup.bat"
  if not exist config.env (
    echo.
    echo Setup did not create config.env, so the relay cannot start.
    pause
    exit /b 1
  )
)

echo Starting the relay. For normal use run install-autostart.bat once instead,
echo so it starts with Windows and keeps running after you close this window.
echo.
node index.js
echo.
echo The relay has stopped. Read the message above to see why.
pause
